# Yemot Audio Worker

Worker שמכין אודיו (WAV PCM16, 8000Hz, mono) מסרטון לפי `videoId`, מפצל למקטעים של 120 שניות, מעלה לימות המשיח (`UploadFile`), מאמת שהקובץ קיים, ומחזיר `playbackPaths` להשמעה ברצף. אין תלות חיצונית ב-npm (Node 22 בלבד), רק `ffmpeg` ו-`yt-dlp`.

## מה הוא לא עושה (בכוונה)
- לא עוקף חסימות, DRM, CAPTCHA, מחליף IP או משתמש ב-cookies. אם המקור לא נותן את האודיו — מוחזר `audio_source_unavailable` והשאר ממשיך לעבוד.
- לא נוגע בשלוחות 1/3 או בשום הגדרה בימות מלבד קבצים תחת `YEMOT_UPLOAD_DIR`.
- לכן **אי אפשר להבטיח "כל סרטון ללא חסימה"**. ראה "מגבלות" למטה.

## API
`GET /health` → `{"status":"ok","ffmpeg":true,"mediaTool":true}` (503 אם כלי חסר)

`POST /prepare-audio` עם `Authorization: Bearer <API_SECRET>`

```json
{ "videoId": "dQw4w9WgXcQ", "title": "לא משמש לזיהוי", "requestId": "abc-1" }
```
הצלחה (200):
```json
{ "status": "ready", "videoId": "dQw4w9WgXcQ", "playbackPaths": ["/2/youtube-audio/dQw4w9WgXcQ-001", "/2/youtube-audio/dQw4w9WgXcQ-002"], "cached": false }
```
לא זמין (422): `{ "status": "unavailable", "reason": "audio_source_unavailable" }`
כשל אחר: 502 / 504 (timeout) `{ "status": "error", "stage": "ffmpeg|yemot-upload|yemot-verify|source|total", "reason": "..." }`
401 ללא הרשאה, 400 קלט לא תקין, 429 rate limit.

## הרצה
```
cp .env.example .env   # למלא ערכים; לא להעלות ל-git
docker build -t yemot-audio-worker .
docker run -d --restart unless-stopped --env-file .env -p 3000:3000 -v audio-data:/app/data yemot-audio-worker
```
ללא Docker: Node 22+, ffmpeg, yt-dlp בנתיב, ואז `npm start`.

## חינם 24/7 — המציאות
- **Oracle Cloud Always Free (VM ARM)**: האפשרות החינמית היחידה שמתאימה באמת (הרשמה דורשת כרטיס אשראי לאימות, ללא חיוב). מתקינים Docker, ושמים Caddy / Cloudflare Tunnel ל-HTTPS.
- **Render / Hugging Face Spaces חינמי**: נרדם בחוסר פעילות, דיסק זמני, מעט זיכרון. מתאים לניסוי, פחות ל-24/7 אמין.
- כתובות IP של דאטה-סנטר (כולל Oracle/Render) נחסמות לא פעם ע"י יוטיוב. אם זה קורה תקבל `audio_source_unavailable`; הפתרון הוא לא לעקוף אלא לבחור תוכן/מקור אחר או לארח ממקום עם IP ביתי (למשל מחשב קטן בבית).

## מהירות
הורדה מקבילית של fragments (`YTDLP_CONCURRENT_FRAGMENTS`), המרה ישירה ל-WAV בלי שלב ביניים, cache לפי `videoId` (בקשה שנייה מיידית), ו-`MAX_JOBS` מקבילים. סרטונים ארוכים משוחררים מהגבלה (`MAX_AUDIO_SECONDS=0`), אבל הם לוקחים זמן ושטח: כל שעה ≈ 57MB בימות (8kHz×16bit).

## משתני סביבה
ראה `.env.example`. חובה: `API_SECRET` (24+ תווים), `YEMOT_API_USERNAME`, `YEMOT_API_PASSWORD`.
`MAX_FILES` סופר מקטעי WAV. `YEMOT_VERIFY_ENDPOINT` ברירת מחדל `DownloadFile` — ודא מול התיעוד של ימות; אם בחשבון שלך הפעולה נקראת `GetFile` שנה כאן.

## בדיקות
`npm test` (16 בדיקות אוטומטיות עם ימות מדומה ו-FFmpeg אמיתי).
`TEST_VIDEO_ID=<id מורשה> npm run test:integration` — בדיקה אמיתית מול ימות ויוטיוב (נדרשים credentials).

## חיבור לשלוחה 2
אחרי ה"כן": POST ל-`/prepare-audio`; אם `status=ready` — השמע את `playbackPaths` ברצף; אחרת הודע שאי אפשר להשמיע.
