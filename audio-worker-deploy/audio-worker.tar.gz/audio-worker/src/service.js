import { mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { Semaphore, SourceUnavailableError, StageError, TimeoutError, sleep, withTimeout } from './util.js';

export function createAudioService({ cfg, yemot, source, converter, cache, log }) {
  const sem = new Semaphore(cfg.maxJobs);
  const inflight = new Map(); // videoId -> Promise

  const names = (videoId, n) =>
    Array.from({ length: n }, (_, i) => `${videoId}-${String(i + 1).padStart(3, '0')}`);

  async function tryCache(videoId, ctx, signal) {
    log('cache lookup', ctx);
    const entry = cache.get(videoId);
    if (!entry) return null;
    try {
      for (const f of entry.files) {
        if (!(await yemot.verify(f, signal))) {
          log('cache entry stale, rebuilding', ctx);
          await cache.delete(videoId);
          return null;
        }
      }
    } catch (e) {
      // cannot confirm existence -> do not claim success from cache
      log('cache verify failed, rebuilding', { ...ctx, reason: e.code || e.name });
      return null;
    }
    log('cache hit', ctx);
    return { status: 'ready', videoId, playbackPaths: entry.playbackPaths, cached: true };
  }

  async function uploadWithRetry(remote, local, ctx, signal) {
    let attempt = 0;
    for (;;) {
      try {
        await yemot.upload(remote, local, signal);
        return;
      } catch (e) {
        const retriable = e instanceof StageError && e.code === 'network' && !(e instanceof TimeoutError);
        if (!retriable || attempt >= cfg.uploadRetries) throw e;
        const wait = cfg.retryBaseMs * 2 ** attempt++;
        log('Yemot upload retry', { ...ctx, attempt, waitMs: wait });
        await sleep(wait);
      }
    }
  }

  async function evict(keepId, ctx) {
    if (!cfg.maxFiles) return;
    for (const old of cache.oldest(keepId)) {
      if (cache.totalFiles() <= cfg.maxFiles) break;
      log('evicting', { ...ctx, evict: old.id });
      let allGone = true;
      for (const f of old.files) {
        try {
          if (!(await yemot.remove(f))) allGone = false;
        } catch {
          allGone = false;
        }
      }
      if (allGone) await cache.delete(old.id);
      else log('evict incomplete, keeping index entry', { ...ctx, evict: old.id });
    }
  }

  async function build(videoId, ctx) {
    await sem.acquire();
    let dir;
    try {
      return await withTimeout('total', cfg.totalJobTimeoutMs, undefined, async (total) => {
        dir = await mkdtemp(path.join(cfg.tmpDir || os.tmpdir(), 'audio-'));
        const input = await withTimeout('source', cfg.sourceTimeoutMs, total, (s) => source.acquire(videoId, dir, s));
        log('source downloaded', ctx);

        log('ffmpeg started', ctx);
        const wavs = await withTimeout('ffmpeg', cfg.ffmpegTimeoutMs, total, (s) => converter.convert(input, dir, s));
        log('ffmpeg completed', { ...ctx, segments: wavs.length });

        const base = names(videoId, wavs.length);
        const remoteFiles = base.map((n) => `${cfg.yemotUploadDir}/${n}.wav`);
        const playbackPaths = base.map((n) => `${cfg.yemotPlayDir}/${n}`);

        for (let i = 0; i < wavs.length; i++) {
          log('Yemot upload started', { ...ctx, part: i + 1 });
          await uploadWithRetry(remoteFiles[i], wavs[i], ctx, total);
          log('Yemot upload completed', { ...ctx, part: i + 1 });
          const ok = await withTimeout('yemot-verify', cfg.yemotVerifyTimeoutMs, total, (s) => yemot.verify(remoteFiles[i], s));
          if (!ok) throw new StageError('yemot-verify', 'file not found in Yemot after upload', { code: 'verify_failed' });
          log('Yemot GetFile verified', { ...ctx, part: i + 1 });
        }

        await cache.set(videoId, { files: remoteFiles, playbackPaths });
        await evict(videoId, ctx).catch((e) => log('evict error', { ...ctx, reason: e.name }));
        return { status: 'ready', videoId, playbackPaths, cached: false };
      });
    } finally {
      sem.release();
      if (dir) await rm(dir, { recursive: true, force: true }).catch(() => {});
    }
  }

  /** Returns a result object; never throws for expected failures. */
  async function prepare({ videoId, requestId }) {
    const ctx = { requestId, videoId };
    log('request received', ctx);

    let job = inflight.get(videoId);
    if (job) log('joining in-flight job', ctx);
    else {
      job = (async () => {
        const hit = await tryCache(videoId, ctx);
        if (hit) return hit;
        return build(videoId, ctx);
      })();
      inflight.set(videoId, job);
      job.then(() => inflight.delete(videoId), () => inflight.delete(videoId));
    }

    try {
      const res = await job;
      log('ready', { ...ctx, cached: res.cached });
      return res;
    } catch (e) {
      const stage = e.stage || 'internal';
      log(`failed stage=${stage}`, { ...ctx, code: e.code || e.name });
      if (e instanceof SourceUnavailableError) return { status: 'unavailable', reason: 'audio_source_unavailable' };
      return { status: 'error', stage, reason: e.code || 'internal_error' };
    }
  }

  return { prepare, _inflight: inflight };
}
