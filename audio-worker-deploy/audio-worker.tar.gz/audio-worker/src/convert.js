import { readdir, readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { runProc, StageError } from './util.js';

/** Converts to WAV PCM s16le 8000 Hz mono, split into segments. Returns ordered file list. */
export function createConverter(cfg) {
  async function convert(input, dir, signal) {
    const pattern = path.join(dir, 'out-%03d.wav');
    const args = [
      '-hide_banner', '-loglevel', 'error', '-nostdin', '-y',
      '-i', input,
      '-vn', '-ar', '8000', '-ac', '1', '-c:a', 'pcm_s16le',
      '-f', 'segment', '-segment_time', String(cfg.segmentSeconds), '-reset_timestamps', '1',
      '-segment_format', 'wav',
      pattern,
    ];
    let r;
    try {
      r = await runProc(cfg.ffmpegBin, args, { signal });
    } catch (e) {
      if (e?.code === 'ENOENT') throw new StageError('ffmpeg', 'ffmpeg not installed', { code: 'tool_missing' });
      throw e;
    }
    if (r.code !== 0) throw new StageError('ffmpeg', `ffmpeg exit ${r.code}`, { code: 'ffmpeg_failed' });

    const files = (await readdir(dir)).filter((f) => /^out-\d{3}\.wav$/.test(f)).sort();
    if (!files.length) throw new StageError('ffmpeg', 'ffmpeg produced no output', { code: 'ffmpeg_failed' });
    const full = files.map((f) => path.join(dir, f));
    for (const f of full) await assertWav(f);
    return full;
  }

  return { convert };
}

/** Do not trust the extension: parse the WAV header. */
export async function assertWav(file) {
  const st = await stat(file).catch(() => null);
  if (!st || st.size <= 44) throw new StageError('ffmpeg', 'output missing or empty', { code: 'ffmpeg_failed' });
  const h = (await readFile(file)).subarray(0, 44);
  const ok =
    h.toString('ascii', 0, 4) === 'RIFF' &&
    h.toString('ascii', 8, 12) === 'WAVE' &&
    h.readUInt16LE(20) === 1 && // PCM
    h.readUInt16LE(22) === 1 && // mono
    h.readUInt32LE(24) === 8000 &&
    h.readUInt16LE(34) === 16;
  if (!ok) throw new StageError('ffmpeg', 'output is not WAV PCM16 8000Hz mono', { code: 'ffmpeg_failed' });
}
