import http from 'node:http';
import crypto from 'node:crypto';
import { REQUEST_ID_RE, VIDEO_ID_RE, runProc } from './util.js';

const sha = (s) => crypto.createHash('sha256').update(s).digest();

export function createServer({ cfg, service, source, log }) {
  const secretHash = sha(cfg.apiSecret);
  const hits = new Map(); // ip -> {count, resetAt}

  function rateLimited(ip) {
    if (!cfg.rateLimitPerMin) return false;
    const now = Date.now();
    let h = hits.get(ip);
    if (!h || h.resetAt <= now) h = { count: 0, resetAt: now + 60_000 };
    h.count++;
    hits.set(ip, h);
    if (hits.size > 10_000) for (const [k, v] of hits) if (v.resetAt <= now) hits.delete(k);
    return h.count > cfg.rateLimitPerMin;
  }

  const send = (res, code, obj) => {
    const body = JSON.stringify(obj);
    res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body) });
    res.end(body);
  };

  function authorized(req) {
    const h = req.headers.authorization || '';
    const m = /^Bearer (.+)$/.exec(h);
    if (!m) return false;
    return crypto.timingSafeEqual(sha(m[1]), secretHash);
  }

  async function readJson(req, limit = 8192) {
    let size = 0;
    const chunks = [];
    for await (const c of req) {
      size += c.length;
      if (size > limit) throw Object.assign(new Error('too large'), { http: 413 });
      chunks.push(c);
    }
    try {
      return JSON.parse(Buffer.concat(chunks).toString('utf8'));
    } catch {
      throw Object.assign(new Error('bad json'), { http: 400 });
    }
  }

  async function health() {
    const ff = await runProc(cfg.ffmpegBin, ['-version']).then((r) => r.code === 0, () => false);
    const mt = await source.version().catch(() => false);
    return { status: ff && mt ? 'ok' : 'degraded', ffmpeg: ff, mediaTool: mt };
  }

  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://x');
      const ip = (cfg.trustProxy && req.headers['x-forwarded-for']?.split(',')[0].trim()) || req.socket.remoteAddress || '?';

      if (req.method === 'GET' && url.pathname === '/health') {
        const h = await health();
        return send(res, h.status === 'ok' ? 200 : 503, h);
      }

      if (req.method === 'POST' && url.pathname === '/prepare-audio') {
        if (rateLimited(ip)) return send(res, 429, { status: 'error', reason: 'rate_limited' });
        if (!authorized(req)) return send(res, 401, { status: 'error', reason: 'unauthorized' });
        const body = await readJson(req);
        const { videoId, requestId } = body || {};
        if (typeof videoId !== 'string' || !VIDEO_ID_RE.test(videoId))
          return send(res, 400, { status: 'error', reason: 'invalid_video_id' });
        if (requestId !== undefined && (typeof requestId !== 'string' || !REQUEST_ID_RE.test(requestId)))
          return send(res, 400, { status: 'error', reason: 'invalid_request_id' });
        // title is informational only and never used for identification
        const result = await service.prepare({ videoId, requestId: requestId || crypto.randomUUID() });
        const code = result.status === 'ready' ? 200 : result.status === 'unavailable' ? 422 : result.reason === 'timeout' ? 504 : 502;
        return send(res, code, result);
      }

      return send(res, 404, { status: 'error', reason: 'not_found' });
    } catch (e) {
      if (e.http) return send(res, e.http, { status: 'error', reason: e.http === 413 ? 'payload_too_large' : 'bad_request' });
      log('failed stage=http', { code: e.name });
      return send(res, 500, { status: 'error', reason: 'internal_error' }); // no stack traces
    }
  });
  server.requestTimeout = 0; // long jobs: the job itself has its own total timeout
  server.headersTimeout = 15_000;
  return server;
}
