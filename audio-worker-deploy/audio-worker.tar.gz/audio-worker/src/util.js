import { spawn } from 'node:child_process';

export class StageError extends Error {
  constructor(stage, message, { code, cause } = {}) {
    super(message);
    this.name = 'StageError';
    this.stage = stage;
    this.code = code || 'stage_failed';
    if (cause) this.cause = cause;
  }
}

export class SourceUnavailableError extends StageError {
  constructor(message = 'audio source unavailable') {
    super('source', message, { code: 'audio_source_unavailable' });
    this.name = 'SourceUnavailableError';
  }
}

export class TimeoutError extends StageError {
  constructor(stage, ms) {
    super(stage, `${stage} timed out after ${ms}ms`, { code: 'timeout' });
    this.name = 'TimeoutError';
  }
}

/** Run fn(signal) with a stage timeout; also aborts when parentSignal aborts. */
export async function withTimeout(stage, ms, parentSignal, fn) {
  const ctrl = new AbortController();
  let timer;
  const onParent = () => ctrl.abort(parentSignal.reason);
  if (parentSignal) {
    if (parentSignal.aborted) throw parentSignal.reason || new TimeoutError('total', 0);
    parentSignal.addEventListener('abort', onParent, { once: true });
  }
  const timeout = new Promise((_, reject) => {
    if (!ms) return;
    timer = setTimeout(() => {
      const err = new TimeoutError(stage, ms);
      ctrl.abort(err);
      reject(err);
    }, ms);
  });
  const aborted = new Promise((_, reject) => {
    ctrl.signal.addEventListener('abort', () => reject(ctrl.signal.reason), { once: true });
  });
  try {
    return await Promise.race([fn(ctrl.signal), timeout, aborted]);
  } finally {
    clearTimeout(timer);
    parentSignal?.removeEventListener('abort', onParent);
  }
}

/** spawn with separate args (never a shell). Kills the child on abort. */
export function runProc(cmd, args, { signal, cwd, captureLimit = 64 * 1024 } = {}) {
  return new Promise((resolve, reject) => {
    let child;
    try {
      child = spawn(cmd, args, { cwd, stdio: ['ignore', 'pipe', 'pipe'], shell: false });
    } catch (e) {
      return reject(e);
    }
    let stdout = '';
    let stderr = '';
    const cap = (s, d) => (s + d).slice(-captureLimit);
    child.stdout.on('data', (d) => (stdout = cap(stdout, d)));
    child.stderr.on('data', (d) => (stderr = cap(stderr, d)));
    const kill = () => child.kill('SIGKILL');
    if (signal) {
      if (signal.aborted) kill();
      else signal.addEventListener('abort', kill, { once: true });
    }
    child.on('error', (e) => {
      signal?.removeEventListener('abort', kill);
      reject(e);
    });
    child.on('close', (code) => {
      signal?.removeEventListener('abort', kill);
      if (signal?.aborted) return reject(signal.reason);
      resolve({ code, stdout, stderr });
    });
  });
}

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export class Semaphore {
  constructor(n) {
    this.n = n;
    this.q = [];
  }
  async acquire() {
    if (this.n > 0) {
      this.n--;
      return;
    }
    await new Promise((r) => this.q.push(r));
  }
  release() {
    const next = this.q.shift();
    if (next) next();
    else this.n++;
  }
}

export function makeLogger(secrets = [], sink = (line) => console.log(line)) {
  const redact = (s) => {
    let out = String(s);
    for (const sec of secrets) if (sec && sec.length >= 4) out = out.split(sec).join('[REDACTED]');
    return out;
  };
  return (msg, ctx = {}) => {
    const tail = Object.entries(ctx)
      .filter(([, v]) => v !== undefined)
      .map(([k, v]) => `${k}=${v}`)
      .join(' ');
    sink(redact(`[AUDIO] ${msg}${tail ? ' ' + tail : ''}`));
  };
}

export const VIDEO_ID_RE = /^[A-Za-z0-9_-]{11}$/;
export const REQUEST_ID_RE = /^[A-Za-z0-9._:-]{1,64}$/;
