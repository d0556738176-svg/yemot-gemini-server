import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';

/** videoId -> { files: [remote upload paths], playbackPaths: [...], createdAt } persisted as JSON. */
export function createCache(dataDir) {
  const file = path.join(dataDir, 'index.json');
  const map = new Map();
  let writing = Promise.resolve();

  async function load() {
    await mkdir(dataDir, { recursive: true });
    try {
      const obj = JSON.parse(await readFile(file, 'utf8'));
      for (const [k, v] of Object.entries(obj)) map.set(k, v);
    } catch {
      /* first run or corrupt index: start empty */
    }
  }

  function persist() {
    const snapshot = JSON.stringify(Object.fromEntries(map));
    writing = writing.then(async () => {
      const tmp = `${file}.tmp`;
      await writeFile(tmp, snapshot);
      await rename(tmp, file);
    }).catch(() => {});
    return writing;
  }

  return {
    load,
    get: (id) => map.get(id),
    async set(id, entry) {
      map.delete(id); // re-insert keeps insertion order == age order
      map.set(id, { ...entry, createdAt: Date.now() });
      await persist();
    },
    async delete(id) {
      map.delete(id);
      await persist();
    },
    totalFiles: () => [...map.values()].reduce((n, e) => n + e.files.length, 0),
    /** Oldest first, excluding `keepId`. */
    oldest(keepId) {
      return [...map.entries()].filter(([id]) => id !== keepId).map(([id, e]) => ({ id, ...e }));
    },
    size: () => map.size,
  };
}
