import { readdir, stat } from 'node:fs/promises';
import path from 'node:path';
import { runProc, SourceUnavailableError, StageError } from './util.js';

/**
 * Acquires the audio of a video with yt-dlp, as a normal client would.
 * No cookies, proxies, IP rotation or other bypass tricks: if the platform refuses,
 * we report audio_source_unavailable and stop.
 */
export function createSource(cfg) {
  async function acquire(videoId, dir, signal) {
    const args = [
      '--no-playlist',
      '--no-warnings',
      '--no-progress',
      '--ignore-config',
      '-f', 'bestaudio/best',
      '--concurrent-fragments', String(cfg.ytdlpConcurrentFragments),
      '-o', path.join(dir, 'source.%(ext)s'),
    ];
    if (cfg.maxSourceBytes > 0) args.push('--max-filesize', String(cfg.maxSourceBytes));
    if (cfg.maxAudioSeconds > 0) args.push('--match-filter', `duration<=${cfg.maxAudioSeconds}`);
    args.push('--', `https://www.youtube.com/watch?v=${videoId}`);

    let r;
    try {
      r = await runProc(cfg.ytdlpBin, args, { signal });
    } catch (e) {
      if (e?.code === 'ENOENT') throw new StageError('source', 'yt-dlp not installed', { code: 'tool_missing' });
      throw e;
    }
    if (r.code !== 0) {
      const tail = String(r.stderr || '').trim().split('\n').slice(-3).join(' | ').slice(0, 400);
      console.log(`[AUDIO] yt-dlp exit=${r.code} videoId=${videoId} stderr=${tail}`);
      throw new SourceUnavailableError(`yt-dlp exit ${r.code}`);
    }

    const files = (await readdir(dir)).filter((f) => f.startsWith('source.') && !f.endsWith('.part'));
    if (!files.length) throw new SourceUnavailableError('no file produced');
    const file = path.join(dir, files[0]);
    const st = await stat(file);
    if (st.size === 0) throw new SourceUnavailableError('empty download');
    if (cfg.maxSourceBytes > 0 && st.size > cfg.maxSourceBytes) throw new SourceUnavailableError('source too large');
    return file;
  }

  async function version(signal) {
    try {
      const r = await runProc(cfg.ytdlpBin, ['--version'], { signal });
      return r.code === 0;
    } catch {
      return false;
    }
  }

  return { acquire, version };
}
