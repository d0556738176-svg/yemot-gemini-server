const int = (env, key, def) => {
  const raw = env[key];
  if (raw === undefined || raw === '') return def;
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 0) throw new Error(`Invalid numeric env ${key}`);
  return n;
};

export function loadConfig(env = process.env) {
  return {
    port: int(env, 'PORT', 3000),
    apiSecret: env.API_SECRET || '',
    yemotUser: env.YEMOT_API_USERNAME || '',
    yemotPass: env.YEMOT_API_PASSWORD || '',
    yemotBase: (env.YEMOT_API_BASE || 'https://www.call2all.co.il/ym/api').replace(/\/+$/, ''),
    yemotUploadDir: (env.YEMOT_UPLOAD_DIR || 'ivr2:/2/youtube-audio').replace(/\/+$/, ''),
    yemotPlayDir: (env.YEMOT_PLAY_DIR || '/2/youtube-audio').replace(/\/+$/, ''),
    // Yemot endpoint used to verify an uploaded file (see README: confirm the name in your account docs)
    yemotVerifyEndpoint: env.YEMOT_VERIFY_ENDPOINT || 'DownloadFile',
    maxFiles: int(env, 'MAX_FILES', 100),
    maxJobs: Math.max(1, int(env, 'MAX_JOBS', 2)),
    // 0 = no limit
    maxSourceBytes: int(env, 'MAX_SOURCE_BYTES', 0),
    maxAudioSeconds: int(env, 'MAX_AUDIO_SECONDS', 0),
    segmentSeconds: Math.max(10, int(env, 'SEGMENT_SECONDS', 120)),
    sourceTimeoutMs: int(env, 'SOURCE_TIMEOUT_MS', 600000),
    ffmpegTimeoutMs: int(env, 'FFMPEG_TIMEOUT_MS', 900000),
    yemotUploadTimeoutMs: int(env, 'YEMOT_UPLOAD_TIMEOUT_MS', 60000),
    yemotVerifyTimeoutMs: int(env, 'YEMOT_VERIFY_TIMEOUT_MS', 15000),
    totalJobTimeoutMs: int(env, 'TOTAL_JOB_TIMEOUT_MS', 3600000),
    uploadRetries: int(env, 'UPLOAD_RETRIES', 3),
    retryBaseMs: int(env, 'RETRY_BASE_MS', 500),
    rateLimitPerMin: int(env, 'RATE_LIMIT_PER_MIN', 60),
    trustProxy: env.TRUST_PROXY === '1',
    dataDir: env.DATA_DIR || './data',
    tmpDir: env.TMP_DIR || '',
    ffmpegBin: env.FFMPEG_BIN || 'ffmpeg',
    ytdlpBin: env.YTDLP_BIN || 'yt-dlp',
    ytdlpConcurrentFragments: int(env, 'YTDLP_CONCURRENT_FRAGMENTS', 4),
  };
}

export function validateRequiredConfig(cfg) {
  const missing = [];
  if (!cfg.apiSecret || cfg.apiSecret.length < 24) missing.push('API_SECRET (min 24 chars)');
  if (!cfg.yemotUser) missing.push('YEMOT_API_USERNAME');
  if (!cfg.yemotPass) missing.push('YEMOT_API_PASSWORD');
  return missing;
}
