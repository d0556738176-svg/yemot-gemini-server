import { readFile } from 'node:fs/promises';
import { StageError, withTimeout } from './util.js';

/**
 * Minimal Yemot HaMashiach API client. Credentials only come from config (env).
 * Success is judged by responseStatus in the JSON body, never by HTTP status alone.
 */
export function createYemot(cfg, fetchImpl = globalThis.fetch) {
  const token = () => `${cfg.yemotUser}:${cfg.yemotPass}`;

  async function upload(remotePath, localFile, signal) {
    const data = await readFile(localFile);
    return withTimeout('yemot-upload', cfg.yemotUploadTimeoutMs, signal, async (sig) => {
      const form = new FormData();
      form.set('token', token());
      form.set('path', remotePath);
      form.set('convertAudio', '0'); // file is already 8kHz mono PCM16
      form.set('upload', new Blob([data], { type: 'audio/wav' }), 'audio.wav');
      let res;
      try {
        res = await fetchImpl(`${cfg.yemotBase}/UploadFile`, { method: 'POST', body: form, signal: sig });
      } catch (e) {
        throw new StageError('yemot-upload', 'network error during UploadFile', { code: 'network', cause: e });
      }
      let body;
      try {
        body = await res.json();
      } catch {
        throw new StageError('yemot-upload', `UploadFile returned non-JSON (HTTP ${res.status})`, { code: 'bad_response' });
      }
      if (!res.ok || body?.responseStatus !== 'OK') {
        throw new StageError('yemot-upload', `UploadFile rejected: ${body?.responseStatus ?? 'unknown'}`, {
          code: res.status >= 500 ? 'network' : 'rejected',
        });
      }
      return true;
    });
  }

  /** Returns true only if the file really exists in Yemot and starts with a RIFF/WAVE header. */
  async function verify(remotePath, signal) {
    return withTimeout('yemot-verify', cfg.yemotVerifyTimeoutMs, signal, async (sig) => {
      const qs = new URLSearchParams({ token: token(), path: remotePath });
      let res;
      try {
        res = await fetchImpl(`${cfg.yemotBase}/${cfg.yemotVerifyEndpoint}?${qs}`, { signal: sig });
      } catch (e) {
        throw new StageError('yemot-verify', 'network error during verify', { code: 'network', cause: e });
      }
      if (!res.ok) return false;
      const ctype = res.headers.get('content-type') || '';
      if (ctype.includes('application/json')) {
        // Yemot reports errors (e.g. file not found) as JSON with responseStatus != OK
        return false;
      }
      const buf = Buffer.from(await res.arrayBuffer());
      return buf.length > 44 && buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WAVE';
    });
  }

  async function remove(remotePath, signal) {
    return withTimeout('yemot-delete', cfg.yemotVerifyTimeoutMs, signal, async (sig) => {
      const qs = new URLSearchParams({ token: token(), action: 'delete', what: remotePath });
      const res = await fetchImpl(`${cfg.yemotBase}/FileAction?${qs}`, { signal: sig });
      const body = await res.json().catch(() => ({}));
      return res.ok && body?.responseStatus === 'OK';
    });
  }

  return { upload, verify, remove };
}
