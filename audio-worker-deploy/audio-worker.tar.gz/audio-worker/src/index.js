import { mkdir } from 'node:fs/promises';
import { loadConfig, validateRequiredConfig } from './config.js';
import { createCache } from './cache.js';
import { createConverter } from './convert.js';
import { createServer } from './server.js';
import { createAudioService } from './service.js';
import { createSource } from './source.js';
import { createYemot } from './yemot.js';
import { makeLogger } from './util.js';

const cfg = loadConfig();
const missing = validateRequiredConfig(cfg);
if (missing.length) {
  console.error(`[AUDIO] missing/invalid configuration: ${missing.join(', ')}`);
  process.exit(1);
}

const log = makeLogger([cfg.apiSecret, cfg.yemotPass, `${cfg.yemotUser}:${cfg.yemotPass}`]);
await mkdir(cfg.dataDir, { recursive: true });
const cache = createCache(cfg.dataDir);
await cache.load();

const source = createSource(cfg);
const service = createAudioService({
  cfg,
  yemot: createYemot(cfg),
  source,
  converter: createConverter(cfg),
  cache,
  log,
});
const server = createServer({ cfg, service, source, log });
server.listen(cfg.port, () => log(`listening on port ${cfg.port}`));

process.on('unhandledRejection', (e) => log('unhandledRejection', { name: e?.name }));
for (const sig of ['SIGTERM', 'SIGINT']) process.on(sig, () => server.close(() => process.exit(0)));
