import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm, readdir, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { loadConfig } from '../src/config.js';
import { createCache } from '../src/cache.js';
import { createConverter } from '../src/convert.js';
import { createServer } from '../src/server.js';
import { createAudioService } from '../src/service.js';
import { createSource } from '../src/source.js';
import { StageError, SourceUnavailableError, makeLogger, runProc } from '../src/util.js';

const SECRET = 'test-secret-test-secret-test-secret';
const VID = 'dQw4w9WgXcQ';

async function genTone(file, seconds) {
  const r = await runProc('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'lavfi', '-i', `sine=frequency=440:duration=${seconds}`, '-ar', '44100', '-ac', '2', file]);
  assert.equal(r.code, 0);
}

function fakeYemot({ failUpload = 0, failUploadHard = false, verifyOk = true } = {}) {
  const files = new Map();
  const calls = { upload: 0, verify: 0, remove: 0 };
  let left = failUpload;
  return {
    files, calls,
    async upload(remote, local) {
      calls.upload++;
      if (failUploadHard) throw new StageError('yemot-upload', 'rejected', { code: 'rejected' });
      if (left-- > 0) throw new StageError('yemot-upload', 'net', { code: 'network' });
      const { readFile } = await import('node:fs/promises');
      files.set(remote, await readFile(local));
    },
    async verify(remote) { calls.verify++; return verifyOk && files.has(remote); },
    async remove(remote) { calls.remove++; return files.delete(remote); },
  };
}

async function setup({ yemot = fakeYemot(), source, cfgOver = {} } = {}) {
  const dataDir = await mkdtemp(path.join(os.tmpdir(), 'aw-data-'));
  const tmpDir = await mkdtemp(path.join(os.tmpdir(), 'aw-tmp-'));
  const cfg = { ...loadConfig({}), apiSecret: SECRET, dataDir, tmpDir, segmentSeconds: 10, retryBaseMs: 1, rateLimitPerMin: 1000, ...cfgOver };
  const cache = createCache(dataDir);
  await cache.load();
  const lines = [];
  const log = makeLogger([SECRET], (l) => lines.push(l));
  let sourceCalls = 0;
  const src = source || {
    async acquire(id, dir) { sourceCalls++; const f = path.join(dir, 'source.wav'); await genTone(f, 25); return f; },
    async version() { return true; },
  };
  const wrapped = { ...src, acquire: async (...a) => { if (!source) return src.acquire(...a); sourceCalls++; return src.acquire(...a); }, version: src.version };
  const service = createAudioService({ cfg, yemot, source: wrapped, converter: createConverter(cfg), cache, log });
  return { cfg, cache, yemot, service, lines, tmpDir, dataDir, get sourceCalls() { return sourceCalls; }, source: wrapped, log };
}

async function http(ctx) {
  const server = createServer({ cfg: ctx.cfg, service: ctx.service, source: ctx.source, log: ctx.log });
  await new Promise((r) => server.listen(0, r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const post = (body, token = SECRET) => fetch(`${base}/prepare-audio`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify(body),
  });
  return { base, post, close: () => new Promise((r) => server.close(r)) };
}

test('health endpoint checks real tools', async () => {
  const ctx = await setup();
  const s = await http(ctx);
  const res = await fetch(`${s.base}/health`);
  const body = await res.json();
  assert.equal(body.ffmpeg, true);
  assert.equal(body.mediaTool, true);
  assert.equal(res.status, 200);
  await s.close();
});

test('health reports degraded when media tool missing', async () => {
  const ctx = await setup({ source: { acquire: async () => {}, version: async () => false } });
  const s = await http(ctx);
  const res = await fetch(`${s.base}/health`);
  assert.equal(res.status, 503);
  assert.equal((await res.json()).mediaTool, false);
  await s.close();
});

test('authentication required', async () => {
  const ctx = await setup();
  const s = await http(ctx);
  assert.equal((await s.post({ videoId: VID }, null)).status, 401);
  assert.equal((await s.post({ videoId: VID }, 'wrong')).status, 401);
  await s.close();
});

test('invalid videoId rejected', async () => {
  const ctx = await setup();
  const s = await http(ctx);
  for (const bad of ['', 'short', '../../etc/passwd', 'a b c d e f g', 'x'.repeat(12), 123, null]) {
    const r = await s.post({ videoId: bad });
    assert.equal(r.status, 400, String(bad));
  }
  await s.close();
});

test('end-to-end with mock Yemot: cache miss then cache hit, segments, format, cleanup', async () => {
  const ctx = await setup();
  const s = await http(ctx);
  const r1 = await s.post({ videoId: VID, title: 'ignored', requestId: 'r1' });
  const b1 = await r1.json();
  assert.equal(r1.status, 200);
  assert.equal(b1.status, 'ready');
  assert.equal(b1.cached, false);
  assert.deepEqual(b1.playbackPaths, ['/2/youtube-audio/' + VID + '-001', '/2/youtube-audio/' + VID + '-002', '/2/youtube-audio/' + VID + '-003']);
  assert.equal(ctx.yemot.files.size, 3);
  for (const [k, buf] of ctx.yemot.files) {
    assert.ok(k.endsWith('.wav'));
    assert.equal(buf.toString('ascii', 0, 4), 'RIFF');
    assert.equal(buf.readUInt16LE(22), 1);
    assert.equal(buf.readUInt32LE(24), 8000);
    assert.equal(buf.readUInt16LE(34), 16);
  }
  assert.deepEqual(await readdir(ctx.tmpDir), [], 'temp files cleaned');

  const r2 = await s.post({ videoId: VID });
  const b2 = await r2.json();
  assert.equal(b2.cached, true);
  assert.equal(ctx.sourceCalls, 1, 'no second download');
  assert.ok(ctx.lines.some((l) => l.includes('ffmpeg completed')));
  assert.ok(!ctx.lines.some((l) => l.includes(SECRET)), 'no secrets in logs');
  await s.close();
});

test('cache entry missing in Yemot triggers rebuild', async () => {
  const ctx = await setup();
  await ctx.service.prepare({ videoId: VID, requestId: 'a' });
  ctx.yemot.files.clear();
  const r = await ctx.service.prepare({ videoId: VID, requestId: 'b' });
  assert.equal(r.status, 'ready');
  assert.equal(r.cached, false);
  assert.equal(ctx.sourceCalls, 2);
});

test('duplicate simultaneous requests share one job', async () => {
  const ctx = await setup();
  const [a, b, c] = await Promise.all([1, 2, 3].map((i) => ctx.service.prepare({ videoId: VID, requestId: 'r' + i })));
  assert.equal(ctx.sourceCalls, 1);
  assert.deepEqual(a.playbackPaths, b.playbackPaths);
  assert.deepEqual(b.playbackPaths, c.playbackPaths);
});

test('ffmpeg failure returns error, no upload, temp cleaned', async () => {
  const source = { async acquire(id, dir) { const f = path.join(dir, 'source.bin'); await writeFile(f, 'not audio at all'); return f; }, version: async () => true };
  const ctx = await setup({ source });
  const r = await ctx.service.prepare({ videoId: VID, requestId: 'x' });
  assert.equal(r.status, 'error');
  assert.equal(r.stage, 'ffmpeg');
  assert.equal(ctx.yemot.calls.upload, 0);
  assert.deepEqual(await readdir(ctx.tmpDir), []);
});

test('source unavailable returns audio_source_unavailable', async () => {
  const source = { async acquire() { throw new SourceUnavailableError(); }, version: async () => true };
  const ctx = await setup({ source });
  const s = await http(ctx);
  const res = await s.post({ videoId: VID });
  assert.equal(res.status, 422);
  assert.deepEqual(await res.json(), { status: 'unavailable', reason: 'audio_source_unavailable' });
  assert.equal(ctx.yemot.calls.upload, 0);
  await s.close();
});

test('Yemot upload failure is not success (hard failure, no retry)', async () => {
  const ctx = await setup({ yemot: fakeYemot({ failUploadHard: true }) });
  const r = await ctx.service.prepare({ videoId: VID, requestId: 'u' });
  assert.equal(r.status, 'error');
  assert.equal(r.stage, 'yemot-upload');
  assert.equal(ctx.yemot.calls.upload, 1);
  assert.equal(ctx.cache.get(VID), undefined);
});

test('transient upload failure is retried with limit', async () => {
  const ctx = await setup({ yemot: fakeYemot({ failUpload: 2 }) });
  const r = await ctx.service.prepare({ videoId: VID, requestId: 'u' });
  assert.equal(r.status, 'ready');
  const ctx2 = await setup({ yemot: fakeYemot({ failUpload: 99 }), cfgOver: { uploadRetries: 2 } });
  const r2 = await ctx2.service.prepare({ videoId: VID, requestId: 'u' });
  assert.equal(r2.status, 'error');
  assert.equal(ctx2.yemot.calls.upload, 3);
});

test('GetFile verification failure is not success', async () => {
  const ctx = await setup({ yemot: fakeYemot({ verifyOk: false }) });
  const r = await ctx.service.prepare({ videoId: VID, requestId: 'v' });
  assert.equal(r.status, 'error');
  assert.equal(r.stage, 'yemot-verify');
  assert.equal(ctx.cache.get(VID), undefined);
});

test('source timeout', async () => {
  const source = { acquire: () => new Promise(() => {}), version: async () => true };
  const ctx = await setup({ source, cfgOver: { sourceTimeoutMs: 100 } });
  const r = await ctx.service.prepare({ videoId: VID, requestId: 't' });
  assert.equal(r.status, 'error');
  assert.equal(r.reason, 'timeout');
  assert.equal(r.stage, 'source');
  // job slot released: a new request can run
  assert.equal(ctx.service._inflight.size, 0);
});

test('cleanup: old entries evicted from index and Yemot when over MAX_FILES', async () => {
  const ctx = await setup({ cfgOver: { maxFiles: 4 } });
  const A = 'AAAAAAAAAAA', B = 'BBBBBBBBBBB';
  await ctx.service.prepare({ videoId: A, requestId: '1' }); // 3 files
  await ctx.service.prepare({ videoId: B, requestId: '2' }); // 3 more -> evict A
  assert.equal(ctx.cache.get(A), undefined);
  assert.ok(ctx.cache.get(B));
  assert.equal(ctx.yemot.files.size, 3);
  assert.ok([...ctx.yemot.files.keys()].every((k) => k.includes(B)));
});

test('MAX_JOBS limits concurrent jobs', async () => {
  let running = 0, peak = 0;
  const source = {
    async acquire(id, dir) {
      running++; peak = Math.max(peak, running);
      await new Promise((r) => setTimeout(r, 100));
      const f = path.join(dir, 'source.wav'); await genTone(f, 2); running--; return f;
    },
    version: async () => true,
  };
  const ctx = await setup({ source, cfgOver: { maxJobs: 2 } });
  const ids = ['AAAAAAAAAA1', 'AAAAAAAAAA2', 'AAAAAAAAAA3', 'AAAAAAAAAA4'];
  const rs = await Promise.all(ids.map((videoId) => ctx.service.prepare({ videoId, requestId: videoId })));
  assert.ok(rs.every((r) => r.status === 'ready'));
  assert.equal(peak, 2);
});

test('yt-dlp argument handling: tool missing is reported, no shell injection surface', async () => {
  const cfg = { ...loadConfig({}), ytdlpBin: 'definitely-not-installed-yt-dlp' };
  const src = createSource(cfg);
  assert.equal(await src.version(), false);
  const dir = await mkdtemp(path.join(os.tmpdir(), 'aw-x-'));
  await assert.rejects(() => src.acquire(VID, dir), (e) => e.code === 'tool_missing');
  await rm(dir, { recursive: true, force: true });
});
