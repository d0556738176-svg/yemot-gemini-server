// Real integration test. Needs: API_SECRET, YEMOT_API_USERNAME, YEMOT_API_PASSWORD, TEST_VIDEO_ID
// (a video you are allowed to download), plus ffmpeg and yt-dlp installed. Logs never contain secrets.
import { mkdtemp } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { loadConfig, validateRequiredConfig } from '../src/config.js';
import { createCache } from '../src/cache.js';
import { createConverter } from '../src/convert.js';
import { createAudioService } from '../src/service.js';
import { createSource } from '../src/source.js';
import { createYemot } from '../src/yemot.js';
import { makeLogger } from '../src/util.js';

const cfg = loadConfig();
const missing = validateRequiredConfig(cfg);
const id = process.env.TEST_VIDEO_ID;
if (missing.length || !id) {
  console.log(`SKIPPED: missing ${[...missing, ...(id ? [] : ['TEST_VIDEO_ID'])].join(', ')}`);
  process.exit(2);
}
cfg.dataDir = await mkdtemp(path.join(os.tmpdir(), 'aw-int-'));
const cache = createCache(cfg.dataDir);
await cache.load();
const log = makeLogger([cfg.apiSecret, cfg.yemotPass, `${cfg.yemotUser}:${cfg.yemotPass}`]);
const service = createAudioService({ cfg, yemot: createYemot(cfg), source: createSource(cfg), converter: createConverter(cfg), cache, log });

const r1 = await service.prepare({ videoId: id, requestId: 'integration-1' });
console.log('first:', JSON.stringify(r1));
const r2 = await service.prepare({ videoId: id, requestId: 'integration-2' });
console.log('second:', JSON.stringify(r2));
const pass = r1.status === 'ready' && r2.status === 'ready' && r2.cached === true;
console.log(pass ? 'INTEGRATION PASS' : 'INTEGRATION FAIL');
process.exit(pass ? 0 : 1);
